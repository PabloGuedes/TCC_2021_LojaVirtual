<?php $__env->startSection('content'); ?>
<style>
    .bg-card {
        background: rgba(0,0,0,0.8);
    color: rgb(223, 223, 223);
    }
 </style>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card bg-card ">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('empresas')); ?>">Voltar</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Request::is('*/edit')): ?>
                            <center>
                                <h5>Selecione e edite o campo desejado</h5>
                            </center>
                            <form action="<?php echo e(url('empresas/update')); ?>/<?php echo e($empresa->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="imagem">Imagem:</label>
                                    </br>
                                    <input type="file" name="imagem" id="imagem" value="<?php echo e($empresa->imagem); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="telefone">Telefone:</label>
                                    <input type="text" name="telefone" class="form-control" id="telefone"
                                        value="<?php echo e($empresa->telefone); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="endereco">Endereço:</label>
                                    <input type="text" name="endereco" class="form-control" id="endereco"
                                        value="<?php echo e($empresa->endereco); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="site">Site:</label>
                                    <input type="text" name="site" class="form-control" id="site"
                                        value="<?php echo e($empresa->site); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="responsavel">Responsável:</label>
                                    <input type="text" name="responsavel" class="form-control" id="responsavel"
                                        value="<?php echo e($empresa->responsavel); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="nome">Nome:</label>
                                    <input type="text" name="nome" class="form-control" id="nome"
                                        value="<?php echo e($empresa->nome); ?>">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Atualizar</button></center>
                            </form>
                        <?php else: ?>
                            <center>
                                <h5>Cadastro de Empresas</h5>
                            </center>
                            <form action="<?php echo e(url('empresas/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="imagem">Imagem:</label>
                                    </br>
                                    <input type="file" name="imagem" id="imagem">
                                </div>
                                <div class="form-group">
                                    <label for="telefone">Telefone:</label>
                                    <input type="text" name="telefone" class="form-control" id="telefone">
                                </div>

                                <div class="form-group">
                                    <label for="endereco">Endereço:</label>
                                    <input type="text" name="endereco" class="form-control" id="endereco">
                                </div>

                                <div class="form-group">
                                    <label for="site">Site:</label>
                                    <input type="text" name="site" class="form-control" id="site">
                                </div>

                                <div class="form-group">
                                    <label for="responsavel">Responsável:</label>
                                    <input type="text" name="responsavel" class="form-control" id="responsavel">
                                </div>

                                <div class="form-group">
                                    <label for="nome">Nome:</label>
                                    <input type="text" name="nome" class="form-control" id="nome">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Loja-Virtual\resources\views/empresas/form.blade.php ENDPATH**/ ?>