<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><center><h5>Painel de Controle</h5></center></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <center><h5>Bem-vindo!</h5></center>
                    <p>Escolha uma das listas abaixo para adicionar um novo item, editar um item existente ou excluí-lo.</p>
                    <a href="<?php echo e(url('categorias')); ?>">Lista de Categorias</a>
                        </br></br>
                    <a href="<?php echo e(url('compras')); ?>">Lista de Compras</a>
                        </br></br>
                    <a href="<?php echo e(url('empresas')); ?>">Lista de Empresas</a>
                        </br></br>
                    <a href="<?php echo e(url('evolucoes')); ?>">Lista de Evoluções</a>
                        </br></br>
                    <a href="<?php echo e(url('imagens')); ?>">Lista de Imagens</a>
                        </br></br>
                    <a href="<?php echo e(url('jogos')); ?>">Lista de Jogos</a>
                        </br></br>
                    <a href="<?php echo e(url('produtos')); ?>">Lista de Produtos</a>
                        </br></br>
                    <a href="<?php echo e(url('usuarios')); ?>">Lista de Usuários</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lojavirtual\resources\views/home.blade.php ENDPATH**/ ?>