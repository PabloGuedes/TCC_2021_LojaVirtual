<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-left: 3%">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card" style="width: 130%;">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('home')); ?>">Voltar</a></center>
                        </br>
                        <center><a href="<?php echo e(url('empresas/new')); ?>">Nova Empresa</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <center>
                            <h5>Lista de Empresas</h5>
                        </center>
                        </br>
                        <table class="table table-bordered" style="position: relative">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Imagem</th>
                                    <th scope="col">Telefone</th>
                                    <th scope="col">Endereço</th>
                                    <th scope="col">Site</th>
                                    <th scope="col">Responsável</th>
                                    <th scope="col">Nome</th>
                                    <th scope="col">Editar</th>
                                    <th scope="col">Deletar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($e->id); ?></th>
                                        <td><?php echo e($e->imagem); ?></td>
                                        <td><?php echo e($e->telefone); ?></td>
                                        <td><?php echo e($e->endereco); ?></td>
                                        <td><?php echo e($e->site); ?></td>
                                        <td><?php echo e($e->responsavel); ?></td>
                                        <td><?php echo e($e->nome); ?></td>
                                        <td>
                                            <a href="empresas/<?php echo e($e->id); ?>/edit" class="btn btn-info">Editar</a>
                                        </td>
                                        <td>
                                            <form action="empresas/delete/<?php echo e($e->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger">Deletar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lojavirtual\resources\views/empresas/list.blade.php ENDPATH**/ ?>