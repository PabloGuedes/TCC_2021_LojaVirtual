<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('jogos')); ?>">Voltar</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Request::is('*/edit')): ?>
                            <center>
                                <h5>Selecione e edite o campo desejado</h5>
                            </center>
                            <form action="<?php echo e(url('jogos/update')); ?>/<?php echo e($jogo->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="responsavel">Responsável:</label>
                                    <input type="text" name="responsavel" class="form-control" id="responsavel"
                                        value="<?php echo e($jogo->responsavel); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="caminho">Caminho:</label>
                                    <input type="text" name="caminho" class="form-control" id="caminho"
                                        value="<?php echo e($jogo->caminho); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao"
                                        value="<?php echo e($jogo->descricao); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="status">Status:</label>
                                    <input type="text" name="status" class="form-control" id="status"
                                        value="<?php echo e($jogo->status); ?>">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Atualizar</button></center>
                            </form>
                        <?php else: ?>
                            <center>
                                <h5>Cadastro de Jogos</h5>
                            </center>
                            <form action="<?php echo e(url('jogos/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="responsavel">Responsável:</label>
                                    <input type="text" name="responsavel" class="form-control" id="responsavel">
                                </div>

                                <div class="form-group">
                                    <label for="caminho">Caminho:</label>
                                    <input type="text" name="caminho" class="form-control" id="caminho">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao">
                                </div>

                                <div class="form-group">
                                    <label for="status">Status:</label>
                                    <input type="text" name="status" class="form-control" id="status">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lojavirtual\resources\views/jogos/form.blade.php ENDPATH**/ ?>