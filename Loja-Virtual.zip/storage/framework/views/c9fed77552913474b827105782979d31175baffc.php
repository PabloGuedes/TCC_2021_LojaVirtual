<?php $__env->startSection('content'); ?>
<style>
    .bg-card {
        background: rgba(0,0,0,0.8);
    color: rgb(223, 223, 223);
    }
 </style>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card bg-card">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('produtos')); ?>">Voltar</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Request::is('*/edit')): ?>
                            <center>
                                <h5>Selecione e edite o campo desejado</h5>
                            </center>
                            <form action="<?php echo e(url('produtos/update')); ?>/<?php echo e($produto->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="data_vencimento">Data de Vencimento:</label>
                                    <input type="text" name="data_vencimento" class="form-control" id="data_vencimento"
                                        value="<?php echo e($produto->data_vencimento); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao"
                                    value="<?php echo e($produto->descricao); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="data_cadastro">Data de Cadastro:</label>
                                    <input type="text" name="data_cadastro" class="form-control" id="data_cadastro"
                                        value="<?php echo e($produto->data_cadastro); ?>">
                                </div>

                                

                                <div class="form-group">
                                    <label for="moedas">Moedas:</label>
                                    <input type="text" name="moedas" class="form-control" id="moedas"
                                        value="<?php echo e($produto->moedas); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="quantidade">Quantidade:</label>
                                    <input type="text" name="quantidade" class="form-control" id="quantidade"
                                        value="<?php echo e($produto->quantidade); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="preco">Preço:</label>
                                    <input type="text" name="preco" class="form-control" id="preco"
                                        value="<?php echo e($produto->preco); ?>">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Atualizar</button></center>
                            </form>
                        <?php else: ?>
                            <center>
                                <h5>Cadastro de Produtos</h5>
                            </center>
                            <form action="<?php echo e(url('produtos/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="data_vencimento">Data de Vencimento:</label>
                                    <input type="text" name="data_vencimento" class="form-control" id="data_vencimento">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao">
                                </div>

                                <div class="form-group">
                                    <label for="data_cadastro">Data de Cadastro:</label>
                                    <input type="text" name="data_cadastro" class="form-control" id="data_cadastro">
                                </div>

                                <div class="form-group">
                                    <label for="categoria_id">Categoria:</label>
                                    <select name="categoria_id" class="form-control" id="categoria_id">
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->descricao); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="moedas">Moedas:</label>
                                    <input type="text" name="moedas" class="form-control" id="moedas">
                                </div>

                                <div class="form-group">
                                    <label for="quantidade">Quantidade:</label>
                                    <input type="text" name="quantidade" class="form-control" id="quantidade">
                                </div>

                                <div class="form-group">
                                    <label for="preco">Preço:</label>
                                    <input type="text" name="preco" class="form-control" id="preco">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Loja-Virtual\resources\views/produtos/form.blade.php ENDPATH**/ ?>