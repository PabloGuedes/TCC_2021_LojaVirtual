<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card" style="width: 110%">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('home')); ?>">Voltar</a></center>
                        </br>
                        <center><a href="<?php echo e(url('usuarios/new')); ?>">Novo Usuário</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <center>
                            <h5>Lista de Usuários</h5>
                        </center>
                        </br>
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">ID do Usuário</th>
                                    <th scope="col">Login</th>
                                    <th scope="col">Senha</th>
                                    <th scope="col">Última atualização</th>
                                    <th scope="col">Saldo de moedas</th>
                                    <th scope="col">Saldo de pontos</th>
                                    <th scope="col">Editar</th>
                                    <th scope="col">Deletar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($u->id); ?></th>
                                        <td><?php echo e($u->idUser); ?></td>
                                        <td><?php echo e($u->login); ?></td>
                                        <td><?php echo e($u->senha); ?></td>
                                        <td><?php echo e($u->ultima_atualizacao); ?></td>
                                        <td><?php echo e($u->saldo_moedas); ?></td>
                                        <td><?php echo e($u->saldo_pontos); ?></td>
                                        <td>
                                            <a href="usuarios/<?php echo e($u->id); ?>/edit" class="btn btn-info">Editar</a>
                                        </td>
                                        <td>
                                            <form action="usuarios/delete/<?php echo e($u->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger">Deletar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lojavirtual\resources\views/usuarios/list.blade.php ENDPATH**/ ?>