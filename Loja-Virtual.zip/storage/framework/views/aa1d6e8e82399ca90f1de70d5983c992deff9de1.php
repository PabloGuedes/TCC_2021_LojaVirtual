<?php $__env->startSection('content'); ?>
<style>
    .bg-card {
        background: rgba(0,0,0,0.8);
    color: rgb(223, 223, 223);
    }
 </style>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card  bg-card ">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('compras')); ?>">Voltar</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Request::is('*/edit')): ?>
                            <center>
                                <h5>Selecione e edite o campo desejado</h5>
                            </center>
                            <form action="<?php echo e(url('compras/update')); ?>/<?php echo e($compra->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="dataHoraCompra">Data e Hora da Compra:</label>
                                    <input type="text" name="dataHoraCompra" class="form-control" id="dataHoraCompra"
                                        value="<?php echo e($compra->dataHoraCompra); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao"
                                        value="<?php echo e($compra->descricao); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="formaDePagamento">Forma de Pagamento:</label>
                                    <input type="text" name="formaDePagamento" class="form-control" id="formaDePagamento"
                                        value="<?php echo e($compra->formaDePagamento); ?>">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Atualizar</button></center>
                            </form>
                        <?php else: ?>
                            <center>
                                <h5>Cadastro de Compras</h5>
                            </center>
                            <form action="<?php echo e(url('compras/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="dataHoraCompra">Data e Hora da Compra:</label>
                                    <input type="text" name="dataHoraCompra" class="form-control" id="dataHoraCompra">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <input type="text" name="descricao" class="form-control" id="descricao">
                                </div>

                                <div class="form-group">
                                    <label for="formaDePagamento">Forma de Pagamento:</label>
                                    <input type="text" name="formaDePagamento" class="form-control" id="formaDePagamento">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Loja-Virtual\resources\views/compras/form.blade.php ENDPATH**/ ?>