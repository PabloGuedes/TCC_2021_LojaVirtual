<?php $__env->startSection('content'); ?>

<style>
    .bg-card {
        background: rgba(0,0,0,0.8);
    color: rgb(223, 223, 223);
    }
 </style>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card bg-card">
                    <div class="card-header">
                        <center><a href="<?php echo e(url('evolucoes')); ?>">Voltar</a></center>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Request::is('*/edit')): ?>
                            <center>
                                <h5>Selecione e edite o campo desejado</h5>
                            </center>
                            <form action="<?php echo e(url('evolucoes/update')); ?>/<?php echo e($evolucao->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="imagem_avatar">Imagem do avatar:</label>
                                    </br>
                                    <input type="file" name="imagem_avatar" id="imagem_avatar"
                                        value="<?php echo e($evolucao->imagem_avatar); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="dataHoraEvolucao">Data e Hora da Evolução:</label>
                                    <input type="text" name="dataHoraEvolucao" class="form-control" id="dataHoraEvolucao"
                                        value="<?php echo e($evolucao->dataHoraEvolucao); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="avatar">Avatar:</label>
                                    <input type="text" name="avatar" class="form-control" id="avatar"
                                        value="<?php echo e($evolucao->avatar); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="jogoEscolhido">Jogo escolhido:</label>
                                    <input type="text" name="jogoEscolhido" class="form-control" id="jogoEscolhido"
                                        value="<?php echo e($evolucao->jogoEscolhido); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="diaJogado">Dia jogado:</label>
                                    <input type="text" name="diaJogado" class="form-control" id="diaJogado"
                                        value="<?php echo e($evolucao->diaJogado); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="pontosConquistados">Pontos conquistados:</label>
                                    <input type="text" name="pontosConquistados" class="form-control" id="pontosConquistados"
                                        value="<?php echo e($evolucao->pontosConquistados); ?>">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Atualizar</button></center>
                            </form>
                        <?php else: ?>
                            <center>
                                <h5>Cadastro de Evoluções</h5>
                            </center>
                            <form action="<?php echo e(url('evolucoes/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="imagem_avatar">Imagem do avatar:</label>
                                    </br>
                                    <input type="file" name="imagem_avatar" id="imagem_avatar">
                                </div>

                                <div class="form-group">
                                    <label for="dataHoraEvolucao">Data e Hora da Evolução:</label>
                                    <input type="text" name="dataHoraEvolucao" class="form-control" id="dataHoraEvolucao">
                                </div>

                                <div class="form-group">
                                    <label for="avatar">Avatar:</label>
                                    <input type="text" name="avatar" class="form-control" id="avatar">
                                </div>

                                <div class="form-group">
                                    <label for="jogoEscolhido">Jogo escolhido:</label>
                                    <input type="text" name="jogoEscolhido" class="form-control" id="jogoEscolhido">
                                </div>

                                <div class="form-group">
                                    <label for="diaJogado">Dia jogado:</label>
                                    <input type="text" name="diaJogado" class="form-control" id="diaJogado">
                                </div>

                                <div class="form-group">
                                    <label for="pontosConquistados">Pontos conquistados:</label>
                                    <input type="text" name="pontosConquistados" class="form-control" id="pontosConquistados">
                                </div>

                                <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Loja-Virtual\resources\views/evolucoes/form.blade.php ENDPATH**/ ?>