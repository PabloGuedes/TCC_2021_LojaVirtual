<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produtos extends Model
{
    protected $fillable = [
        'id',
        'data_vencimento',
        'descricao',
        'data_cadastro',
        'categoria_id',
        'moedas',
        'quantidade',
        'preco'
    ];

    public function categoria(){
        return $this->belongsTo(Categoria::class, 'categoria_id');
    }

    public function categorias()
    {
        return $this->belongsToMany(Categoria::class);
    }
}
